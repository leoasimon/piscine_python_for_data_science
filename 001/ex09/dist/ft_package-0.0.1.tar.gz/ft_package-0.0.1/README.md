# Boardgame Utils

This is a simple package, it allows you to perform common board and card games actions, like throwing dices or picking up cards.

Have fun!
