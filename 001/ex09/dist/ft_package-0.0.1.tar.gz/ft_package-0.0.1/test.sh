#! /bin/bash

python -m build
pip install ./dist/ft_package-0.0.1.tar.gz
